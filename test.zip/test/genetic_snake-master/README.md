# Evolutionary Snake

Click image to see demo video!
[![https://youtu.be/C4WH5b-EidU](https://github.com/kairess/genetic_snake/raw/master/result.png)](https://youtu.be/C4WH5b-EidU)

## Run
```
python evolution.py
```

## Dependencies
- Python 3+
- numpy
- pygame

Snake game code by HonzaKral: https://gist.github.com/HonzaKral/833ee2b30231c53ec78e
